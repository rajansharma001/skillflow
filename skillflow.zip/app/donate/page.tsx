import PageHeading from "@/components/PageHeading";
import React from "react";

const Donate = () => {
  return (
    <div>
      <PageHeading pageTitle="Donate" />
    </div>
  );
};

export default Donate;
