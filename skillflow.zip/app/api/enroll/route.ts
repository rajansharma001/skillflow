import { auth } from "@/auth";
import { prisma } from "@/prisma/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body = await req.json();
  console.log("am i getting form data from form", body);

  const { courseId, userId } = body;

  const postEnroll = await prisma.enroll.create({
    data: {
      courseId: courseId,
      userId: userId,
    },
  });

  return NextResponse.json(
    { message: "Enrollment Successfull" },
    { status: 200 }
  );
}

export async function GET(req: NextRequest) {
  const session = await auth();
  const sessinUserId = session?.user.id;
  const getEnroll = await prisma.enroll.findMany({
    where: { userId: sessinUserId },
  });

  return NextResponse.json({ getEnroll });
}
