"use server";
import NewCourse from "@/app/dashboard/course/new_course/page";
import { auth } from "@/auth";
import { prisma } from "@/prisma/prisma";
import { writeFile } from "fs/promises";
import { NextRequest, NextResponse } from "next/server";
import { join } from "path";

export async function POST(req: any) {
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json(
      { error: "User not authenticated" },
      { status: 401 }
    );
  }

  const data = await req.formData();
  const title = data.get("title");
  const slug = data.get("slug");
  const description = data.get("description");
  const thumbnailUrl = data.get("thumbnailUrl");
  const isFree = data.get("isFree") === "true";
  const price = data.get("price");
  const level = data.get("level");
  const language = data.get("language");
  const duration = data.get("duration");
  const category_id = data.get("category_id");
  const previewVideoUrl = data.get("previewVideoUrl");

  console.log(data);

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const user_id = user.id;

  // process for file upload
  // Save thumbnail file
  let thumbnailPath = "";
  if (thumbnailUrl) {
    const thumbBytes = await thumbnailUrl.arrayBuffer();
    const thumbBuffer = Buffer.from(thumbBytes);
    thumbnailPath = `/tmp/${thumbnailUrl.name}`;
    await writeFile(thumbnailPath, thumbBuffer);
  }

  // Save preview video file
  let previewVideoPath = "";
  if (previewVideoUrl) {
    const previewBytes = await previewVideoUrl.arrayBuffer();
    const previewBuffer = Buffer.from(previewBytes);
    previewVideoPath = `/tmp/${previewVideoUrl.name}`;
    await writeFile(previewVideoPath, previewBuffer);
  }

  const newCourse = await prisma.course.create({
    data: {
      title: title,
      slug: slug,
      description: description,
      thumbnailUrl: thumbnailPath,
      isFree,
      price: price,
      level: level,
      language: language,
      duration: duration,
      category_id: category_id,
      authorId: user_id,
      previewVideoUrl: previewVideoPath,
    },
  });
  return NextResponse.json(
    { message: "Course Added", newCourse },
    { status: 200 }
  );
}

export async function GET(req: NextRequest) {
  const session = await auth();
  const authorId = session?.user.id;
  const getCourse = await prisma.course.findMany({
    where: { authorId },
  });

  return NextResponse.json(getCourse);
}
