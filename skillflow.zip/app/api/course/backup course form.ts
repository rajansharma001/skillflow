"use server";
import NewCourse from "@/app/dashboard/course/new_course/page";
import { auth } from "@/auth";
import { prisma } from "@/prisma/prisma";
import { rejects } from "assert";
import { NextRequest, NextResponse } from "next/server";

interface InputType {
  c_title: string;
  c_slug: string;
  c_description: string;
  c_thambnailUrl: string;
  c_isFree: boolean;
  c_price: string;
  c_level: string;
  c_language: string;
  c_duration: string;
  c_category: string;
  c_previewVideoUrl: string;
}

export async function POST(req: any) {
  const body: InputType = await req.json();
  const session = await auth();

  if (!session?.user?.email) {
    return NextResponse.json(
      { error: "User not authenticated" },
      { status: 401 }
    );
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const user_id = user.id;

  //   fetch category

  const {
    c_title,
    c_slug,
    c_description,
    c_thambnailUrl,
    c_isFree,
    c_price,
    c_level,
    c_language,
    c_duration,
    c_category,
    c_previewVideoUrl,
  } = body;

  if (!body)
    return NextResponse.json({ message: "data not fetched" }, { status: 405 });
  console.log("data fetched");
  console.log(body);

  const newCourse = await prisma.course.create({
    data: {
      title: c_title,
      slug: c_slug,
      description: c_description,
      thumbnailUrl: c_thambnailUrl,
      isFree: c_isFree,
      price: c_price,
      level: c_level,
      language: c_language,
      duration: c_duration,
      category_id: c_category,
      authorId: user_id,
      previewVideoUrl: c_previewVideoUrl,
    },
  });
  return NextResponse.json(
    { message: "Course Added", course: newCourse },
    { status: 200 }
  );
}

export async function GET(req: NextRequest) {
  const session = await auth();
  const authorId = session?.user.id;
  const getCourse = await prisma.course.findMany({
    where: { authorId },
  });

  return NextResponse.json(getCourse);
}
