import Lesson from "@/app/dashboard/lesson/page";
import { auth } from "@/auth";
import { prisma } from "@/prisma/prisma";
import { NextRequest, NextResponse } from "next/server";

export const config = {
  api: {
    bodyParser: false,
  },
};
export async function POST(req: any) {
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json(
      { error: "User not authenticated" },
      { status: 401 }
    );
  }

  const data = await req.formData();
  const title = data.get("title");
  const slug = data.get("slug");
  const description = data.get("description");
  const thumbnailUrl = data.get("thumbnailUrl");
  const isFree = data.get("isFree") === "true";
  const price = data.get("price");
  const level = data.get("level");
  const language = data.get("language");
  const duration = data.get("duration");
  const category_id = data.get("category_id");
  // const previewVideoUrl = data.get("previewVideoUrl");

  console.log(data);

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const user_id = user.id;

  const newCourse = await prisma.course.create({
    data: {
      title: title,
      slug: slug,
      description: description,
      thumbnailUrl: thumbnailUrl,
      isFree,
      price: price,
      level: level,
      language: language,
      duration: duration,
      category_id: category_id,
      authorId: user_id,
      // previewVideoUrl: previewVideoUrl,
    },
  });
  return NextResponse.json(
    { message: "Course Added", newCourse },
    { status: 200 }
  );

  // ////////////////////////////////////////////////
}

export async function GET(req: NextRequest) {
  const session = await auth();
  const authorId = session?.user.id;

  const getCourse = await prisma.course.findMany({
    where: { authorId },
    include: { lesson: true, category: true, user: true },
  });

  return NextResponse.json(getCourse);
}
