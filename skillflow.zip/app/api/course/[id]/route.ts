import { prisma } from "@/prisma/prisma";
import { InputType } from "@/types";
import { Params } from "next/dist/server/request/params";
import { NextRequest, NextResponse } from "next/server";
export const config = {
  api: {
    bodyParser: false,
  },
};
export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> } // params is a Promise here!
) {
  const params = await context.params; // await params first
  const id = params.id;

  try {
    const deletedCourse = await prisma.course.delete({
      where: { id },
    });
    if (deletedCourse)
      return NextResponse.json(
        { message: "is DELETE FUNC getting course" },
        { status: 200 }
      );
    return NextResponse.json({ message: "Course Deleted" }, { status: 200 });
  } catch (error) {
    console.error("Error deleting course:", error);
    return NextResponse.json(
      { message: "Deletion failed", error },
      { status: 500 }
    );
  }
}

export async function GET(req: Request, context: { params: { id: string } }) {
  const { id } = await context.params;

  if (!id || typeof id !== "string") {
    return NextResponse.json(
      { message: "Invalid or missing ID" },
      { status: 400 }
    );
  }

  const getCourse = await prisma.course.findUnique({
    where: { id },
  });

  if (!getCourse)
    return NextResponse.json({ message: "course not found" }, { status: 404 });

  return NextResponse.json(getCourse, { status: 200 });
}

export async function PUT(
  req: NextRequest,
  context: { params: { id: string } }
) {
  const { id } = await context.params;

  const body: InputType = await req.json();

  const {
    title,
    slug,
    description,
    thumbnailUrl,
    isFree,
    price,
    level,
    language,
    duration,
    category_id,
    // previewVideoUrl,
  } = body;

  console.log(body.thumbnailUrl);

  const updateCourse = await prisma.course.update({
    data: {
      title: title,
      slug: slug,
      description: description,
      thumbnailUrl: thumbnailUrl,
      isFree: isFree,
      price: price,
      level: level,
      language: language,
      duration: duration,
      category_id: category_id,
      // previewVideoUrl: previewVideoUrl,
    },
    where: { id },
  });

  if (!updateCourse)
    return NextResponse.json({ message: "updation failed" }, { status: 404 });
  return NextResponse.json({ message: "Course Updated" }, { status: 200 });
}
