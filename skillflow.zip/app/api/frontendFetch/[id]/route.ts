import { prisma } from "@/prisma/prisma";
import { error } from "console";
import { NextRequest, NextResponse } from "next/server";

interface Props {
  params: string;
}
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { id } = await params;

  if (!id) return NextResponse.json({ error: "ID not found" }, { status: 404 });

  const getCourse = await prisma.course.findUnique({
    where: { id },
    include: { category: true, lesson: true, user: true },
  });

  return NextResponse.json(getCourse);
}
