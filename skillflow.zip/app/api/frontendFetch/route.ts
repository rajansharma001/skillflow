import { prisma } from "@/prisma/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const getCourse = await prisma.course.findMany({
    include: { lesson: true, category: true, user: true, enroll: true },
  });

  return NextResponse.json(getCourse);
}
