import { auth } from "@/auth";
import { prisma } from "@/prisma/prisma";
import { Lesson } from "@/types";
import { NextRequest, NextResponse } from "next/server";

export async function DELETE(
  req: NextRequest,
  context: { params: { id: string } }
) {
  const { id } = await context.params;
  const deleteLesson = await prisma.lesson.delete({
    where: { id },
  });
  return NextResponse.json({ message: "Lesson deleted Success" });
}

export async function GET(
  req: NextRequest,
  context: { params: { id: string } }
) {
  const { id } = await context.params;

  const getLesson = await prisma.lesson.findUnique({ where: { id } });
  return NextResponse.json(getLesson);
}

export async function PUT(
  req: NextRequest,
  context: { params: { id: string } }
) {
  const body: Lesson = await req.json();

  console.log(body);

  const {
    title,
    slug,
    videoUrl,
    videoLength,
    courseId,
    isFree,
    summary,
    resources,
  } = body;
  const { id } = await context.params;

  const exisitingLesson = await prisma.lesson.findUnique({ where: { id } });
  console.log("before update:", exisitingLesson);

  const updateLesson = await prisma.lesson.update({
    where: { id },
    data: {
      title: title,
      slug: slug,
      videoUrl: videoUrl,
      videoLength: videoLength,
      courseId: courseId,
      isFree: isFree,
      summary: summary,
      resources: resources,
    },
  });

  if (!updateLesson) {
    console.log("Got an error while updating lesson");
    return NextResponse.json({ message: "Update failed" }, { status: 405 });
  }
  console.log("lesson updated");
  return NextResponse.json(
    { message: "Lesson Updated Success" },
    { status: 200 }
  );
}
