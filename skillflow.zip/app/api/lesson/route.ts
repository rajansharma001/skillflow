import { prisma } from "@/prisma/prisma";
import { Lesson } from "@/types";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body: Lesson = await req.json();
  const {
    title,
    slug,
    videoUrl,
    courseId,
    isFree,
    resources,
    summary,
    videoLength,
  } = body;

  const newLesson = await prisma.lesson.create({
    data: {
      title: title,
      slug: slug,
      videoUrl: videoUrl,
      courseId: courseId,
      isFree: isFree,
      resources: resources,
      summary: summary,
      videoLength: videoLength,
    },
  });
  if (!newLesson)
    return NextResponse.json(
      { message: "Error while creating course" },
      { status: 405 }
    );

  return NextResponse.json({ message: "Lesson Created" }, { status: 200 });
}

export async function GET(req: NextRequest) {
  const getLesson = await prisma.lesson.findMany();

  return NextResponse.json(getLesson);
}
