import { prisma } from "@/prisma/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  const getData = await prisma.user.findMany();

  console.log(getData);
  if (!getData)
    return NextResponse.json({ error: "data not found" }, { status: 404 });

  return NextResponse.json(getData);
}
