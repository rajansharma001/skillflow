import { prisma } from "@/prisma/prisma";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const { id } = await params;
  await prisma.courseCategory.delete({
    where: { id },
  });
  return NextResponse.json({ message: "Category deleted" }, { status: 200 });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const body = await req.json();
  console.log(body);

  const { id } = await params;
  await prisma.courseCategory.update({
    data: {
      name: body.editCat,
      slug: body.editSlug,
    },
    where: { id },
  });
  return NextResponse.json({ message: "Category Updated" }, { status: 200 });
}
