import { prisma } from "@/prisma/prisma";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();

  if (!body) NextResponse.json({ message: "category data not found" });

  const NewCategory = await prisma.courseCategory.create({
    data: {
      name: body.cat_name,
      slug: body.cat_slug,
    },
  });
  if (!NewCategory)
    return NextResponse.json({ message: "Category Submission failed" });

  return NextResponse.json(
    { success: "Created Successfully" },
    { status: 200 }
  );
}

export async function GET(req: Request) {
  const getCat = await prisma.courseCategory.findMany();
  return NextResponse.json(getCat);
}
