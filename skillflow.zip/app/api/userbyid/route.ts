import { auth } from "@/auth";
import { prisma } from "@/prisma/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  const sessionId = await session?.user.id;

  const getUserByID = await prisma.user.findUnique({
    where: { id: sessionId },
  });

  return NextResponse.json({ getUserByID });
}
