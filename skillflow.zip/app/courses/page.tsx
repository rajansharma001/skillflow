import PageHeading from "@/components/PageHeading";
import React from "react";

const Courses = () => {
  return (
    <div>
      <PageHeading pageTitle="Courses" />
    </div>
  );
};

export default Courses;
