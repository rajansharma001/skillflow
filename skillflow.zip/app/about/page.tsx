import PageHeading from "@/components/PageHeading";
import React from "react";

const About = () => {
  return (
    <div>
      <PageHeading pageTitle="About Us" />
    </div>
  );
};

export default About;
