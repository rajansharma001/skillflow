import React from "react";

const NewCourse = () => {
  return <div>NewCourse</div>;
};

export default NewCourse;
