import UserPage from "@/components/user/UserPage";
import React from "react";

const User = () => {
  return (
    <div>
      <UserPage />
    </div>
  );
};

export default User;
