import PageHeading from "@/components/PageHeading";
import React from "react";

const Contact = () => {
  return (
    <div>
      <PageHeading pageTitle="Contact Us" />
    </div>
  );
};

export default Contact;
